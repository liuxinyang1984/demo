<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

User:<?php echo e($name); ?>


<?php echo 'Blade'.(1+1)?>

<br>
<br>


<?php if($num > 10): ?>
    num大于10
<?php elseif($num > 5): ?>
    num大于5
<?php else: ?>
    num小于5
<?php endif; ?>

<?php if (! ($num > 5)): ?>
    num小于5
<?php endif; ?>

<?php if(isset($num)): ?>
    num存在
<?php endif; ?>


<?php switch($num):
    case (1): ?>
        1
        <?php break; ?>
    <?php case (4): ?>
        4
        <?php break; ?>
    <?php default: ?>
        不存在
<?php endswitch; ?>

<br>
<br>


<?php for($i = 0; $i <= 10; $i++): ?>
    <?php echo e($i); ?> --
<?php endfor; ?>

<br>
<br>

<?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($user->username); ?> --
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<br>

<?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($user->username == '樱桃小丸子'): ?>
        <?php continue; ?>
    <?php endif; ?>
    <?php echo e($user->username); ?> --
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<br>

<?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($user->username == '樱桃小丸子'): ?>
        <?php break; ?>
    <?php endif; ?>
    <?php echo e($user->username); ?> --
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<br>
<br>



<?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($loop->first): ?>
        [起始数据之前]
    <?php endif; ?>

    <?php if($loop->last): ?>
        [末尾数据之前]
    <?php endif; ?>


    <?php echo e($user->username); ?> --
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php
    echo 1+1
?>


</body>
</html>
<?php /**PATH C:\wamp\www\laravel\resources\views/user.blade.php ENDPATH**/ ?>