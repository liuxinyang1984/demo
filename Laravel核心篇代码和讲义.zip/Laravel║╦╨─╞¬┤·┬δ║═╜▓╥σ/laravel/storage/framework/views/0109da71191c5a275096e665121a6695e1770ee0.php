<?php $__env->startSection('title', '首页'); ?>

<?php $__env->startSection('main'); ?>
    <p>内容</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
    <a href="#">首页</a>
<?php $__env->stopSection(); ?>


<br>

<?php echo e($name); ?> <?php echo $name; ?>


<?php echo json_encode($list, JSON_PRETTY_PRINT, 512) ?>

@{{$name}}

<?php echo $__env->make('public/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\laravel\resources\views/index.blade.php ENDPATH**/ ?>