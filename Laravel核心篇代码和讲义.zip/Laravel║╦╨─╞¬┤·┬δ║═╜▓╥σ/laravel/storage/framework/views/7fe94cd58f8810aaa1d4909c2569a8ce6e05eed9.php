<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>提交</title>
</head>
<body>









<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>






<form action="/task/receive" method="post">
    <?php echo csrf_field(); ?>
    用户名：<input type="text" name="username" value="<?php echo e(old('username')); ?>">
    密码：<input type="password" name="password">
    密码确认：<input type="password" name="password_confirmation">
    <button type="submit">提交</button>
</form>





</body>
</html>
<?php /**PATH C:\wamp\www\laravel\resources\views/form.blade.php ENDPATH**/ ?>