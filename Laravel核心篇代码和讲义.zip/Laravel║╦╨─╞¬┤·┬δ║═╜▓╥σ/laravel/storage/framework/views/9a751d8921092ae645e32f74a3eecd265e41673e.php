<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?> -- <?php echo $__env->yieldContent('title', 'no title'); ?></title>
</head>
<body>

Base

<?php $__env->startSection('sidebar'); ?>
    <ol>
        <li><a href="#">导航</a></li>
    </ol>
<?php echo $__env->yieldSection(); ?>

<div class="container">
    <?php echo $__env->yieldContent('main'); ?>
</div>



</body>
</html>
<?php /**PATH C:\wamp\www\laravel\resources\views/public/base.blade.php ENDPATH**/ ?>