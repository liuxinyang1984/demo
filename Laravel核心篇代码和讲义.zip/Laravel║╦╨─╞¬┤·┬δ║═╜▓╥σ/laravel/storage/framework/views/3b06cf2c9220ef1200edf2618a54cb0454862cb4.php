<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>模型</title>
</head>
<body>


<table border="1">
    <tr>
        <th>ID</th>
        <th>用户名</th>
        <th>性别</th>
        <th>邮箱</th>
    </tr>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->id); ?></td>
        <td><?php echo e($user->username); ?></td>
        <td><?php echo e($user->gender); ?></td>
        <td><?php echo e($user->email); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>



<?php echo e($list->onEachSide(2)->links()); ?>



</body>
</html>
<?php /**PATH C:\wamp\www\laravel\resources\views/data.blade.php ENDPATH**/ ?>