<?php
namespace App\Http\Controllers\Admin;

class ManageController
{
    public function index()
    {
        return 'Manage';
    }
}
