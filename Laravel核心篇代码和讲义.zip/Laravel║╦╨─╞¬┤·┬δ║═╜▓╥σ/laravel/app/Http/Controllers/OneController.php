<?php
namespace App\Http\Controllers;

class OneController extends Controller
{
    public function __invoke()
    {
        // TODO: Implement __invoke() method.
        return '单行为控制器！';
    }
}
